
'use client';
import React,{useState} from 'react';
import dynamic from 'next/dynamic';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const Lro = dynamic(()=>import('../components/Lro'), { ssr:false });

export default function Page(){
  const [id,setId]=useState<number|null>(null);
  const [name,setName]=useState('');
  const savePNG=async()=>{const el=document.getElementById('cert'); if(!el) return; const c=await html2canvas(el,{scale:2}); const a=document.createElement('a'); a.href=c.toDataURL('image/png'); a.download='lunar-certificate.png'; a.click();};
  const savePDF=async()=>{const el=document.getElementById('cert'); if(!el) return; const c=await html2canvas(el,{scale:2}); const pdf=new jsPDF('p','pt','a4'); const img=c.toDataURL('image/png'); const w=pdf.internal.pageSize.getWidth(), h=pdf.internal.pageSize.getHeight(); const ratio=Math.min(w/c.width, h/c.height); const iw=c.width*ratio, ih=c.height*ratio; pdf.addImage(img,'PNG',(w-iw)/2,40,iw,ih); pdf.save('lunar-certificate.pdf');};
  return (<main className="px-4 py-8">
    <h1 className="text-3xl font-bold mb-2">Lunar Birthright — Prototype</h1>
    <p className="text-sm text-gray-600 mb-4">Pick a spot on real lunar imagery, then generate a symbolic certificate.</p>
    <Lro onPick={(n:number)=>setId(n)} />
    <section className="mx-auto max-w-4xl mt-6 p-4 border rounded-2xl">
      <div className="grid gap-3 sm:grid-cols-3">
        <input className="rounded-xl border px-3 py-2" placeholder="Your full name" value={name} onChange={e=>setName(e.target.value)} />
        <div className="py-2 text-sm">Section: {id ?? '—'}</div>
        <button className="btn btn-primary" disabled={!id||!name} onClick={savePNG}>Download PNG</button>
      </div>
      <div className="mt-2">
        <button className="btn btn-ghost" disabled={!id||!name} onClick={savePDF}>Download PDF</button>
      </div>
    </section>
    {id&&name&&(<section id="cert" className="mx-auto max-w-3xl mt-6 p-6 border rounded-2xl">
      <div className="text-center text-xs text-gray-600 mb-1">Symbolic Certificate</div>
      <h2 className="text-center text-2xl font-semibold mb-4">Lunar Birthright Project™</h2>
      <div className="text-center text-sm mb-2">This certifies that</div>
      <div className="text-center text-xl font-semibold mb-2">{name}</div>
      <div className="text-center text-sm">is symbolic steward of Section #{id}</div>
      <div className="mt-4 text-center text-xs text-gray-600">Not a legal land title · OST compliant</div>
    </section>)}
  </main>);
}
