
'use client';
import dynamic from 'next/dynamic';
const MapContainer:any = dynamic(async()=> (await import('react-leaflet')).MapContainer, { ssr:false });
const TileLayer:any = dynamic(async()=> (await import('react-leaflet')).TileLayer, { ssr:false });

export default function Lro({ onPick }:{ onPick:(id:number)=>void }){
  const URL = process.env.NEXT_PUBLIC_LRO_TILE_URL || 'https://trek.nasa.gov/tiles/Moon/EQ/LRO_WAC_Mosaic_Global_303ppd/{z}/{x}/{y}.png';
  const click = (e:any)=>{
    const lat = e.latlng.lat, lon = e.latlng.lng;
    const id = Math.floor(((90-lat)/180)*1800)*3600 + Math.floor(((lon+180)/360)*3600) + 1;
    onPick(id);
  };
  return (
    <div className="mx-auto max-w-4xl">
      <MapContainer center={[0,0]} zoom={1} scrollWheelZoom className="leaflet-container" whenCreated={(m:any)=>m.on('click', click)}>
        <TileLayer url={URL} />
      </MapContainer>
      <div className="mt-2 text-xs text-gray-600">Tiles: {URL}</div>
    </div>
  );
}
