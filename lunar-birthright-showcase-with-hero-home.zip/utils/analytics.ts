export type AnalyticsEvent =
  | 'ribbon_shown' | 'ribbon_collapsed' | 'ribbon_expanded' | 'ribbon_dismissed' | 'ribbon_learn_more'
  | 'footer_shown' | 'footer_dismissed' | 'footer_learn_more'
  | 'claim_save_ok' | 'claim_save_stub' | 'claim_save_err'
  | 'download_png' | 'download_pdf' | 'copy_coords'
  | 'registry_view' | 'registry_edit';

export function logEvent(name: AnalyticsEvent, params?: Record<string, any>) {
  console.log('[analytics]', name, params || {});

  if (typeof document !== 'undefined') {
    document.dispatchEvent(new CustomEvent('lb_analytics', { detail: { name, params }}));
  }

  if (typeof window !== 'undefined') {
    // @ts-ignore
    if (window.gtag) window.gtag('event', name, params || {});
    // @ts-ignore
    if (window.plausible) window.plausible(name, { props: params || {} });
    // @ts-ignore
    if (window.dataLayer && Array.isArray(window.dataLayer)) window.dataLayer.push({ event: name, ...(params || {}) });
  }
}
