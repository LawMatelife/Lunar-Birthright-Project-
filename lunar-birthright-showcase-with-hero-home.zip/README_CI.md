# Vercel CI/CD Add‑on (GitHub Actions)

This add‑on gives you:
- **.github/workflows/deploy-vercel.yml** — builds your Next.js app on every push to `main` and deploys to Vercel.
- **vercel.json** — optional config with defaults.
- **app/api/registry/route.ts** — a stub API for `/api/registry` so the UI works before you wire your DB.

## How to use

1) **Download this ZIP** and extract its contents into the **root** of your GitHub repo (the folder that contains `package.json`). Commit + push.

2) In your GitHub repo, go to **Settings → Secrets and variables → Actions → New repository secret** and add:
   - `VERCEL_TOKEN` — your personal Vercel token
   - *(optional but recommended)* `VERCEL_ORG_ID` and `VERCEL_PROJECT_ID` if your Vercel project already exists

3) Get the token and IDs from Vercel:
   - Token: Vercel Dashboard → **Account Settings → Tokens → Create Token**
   - Org/Project IDs: Vercel → Your Project → **Settings → General** (scroll to "IDs")

4) The workflow triggers on pushes to `main`. To run it immediately, go to **Actions → Deploy to Vercel (Next.js) → Run workflow**.

5) Ensure your `package.json` has:
```json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  }
}
```

## Notes

- The workflow uses Node 18 and `npm ci` for clean installs.
- The stub API returns `{ ok: true, stub: true }` on POST and a blank record on GET. Replace with your real DB logic when ready.
- You can also set environment variables in Vercel Project → **Settings → Environment Variables** (e.g., tile URLs, BASE_URL).

Generated: 2025-10-31T05:53:54.949679Z
