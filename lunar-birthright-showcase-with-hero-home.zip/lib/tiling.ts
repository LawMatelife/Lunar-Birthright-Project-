export function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}
export function indexToCoord(id: number, step = 0.1) {
  const W = Math.round(360 / step);
  const H = Math.round(180 / step);
  const i = clamp(id - 1, 0, W * H - 1);
  const y = Math.floor(i / W);
  const x = i % W;
  const lon = (x / W) * 360 - 180;
  const lat = 90 - (y / H) * 180;
  return { lat: +lat.toFixed(4), lon: +lon.toFixed(4) };
}
