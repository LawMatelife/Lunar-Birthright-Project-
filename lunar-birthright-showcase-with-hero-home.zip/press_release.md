# Press Release — For Immediate Release

**Lunar Birthright Project**  
*“A symbolic global birthright giving every human a piece of the Moon.”*

**Fairlie, New Zealand — 31 October 2025** — The Lunar Birthright Project unveils a visionary, educational initiative that connects every person on Earth with a *symbolic* section of the Moon. Powered by authentic NASA lunar imagery and guided by the 1967 **Outer Space Treaty (OST)**, Lunar Birthright transforms the dream of space ownership into a story of unity, imagination, and peaceful exploration.

> “This project represents a vision of unity and imagination — a global birthright that connects every child of Earth to the Moon.”  
> — **Daniel Heslip**, Creator, Lunar Birthright

## What It Is
- A **digital registry** that assigns each participant a **non-legal, symbolic lunar section** (quarter-acre equivalent) on a real lunar map.  
- A **certificate generator** that provides a shareable PDF/PNG, with coordinates and a QR code for verification.  
- An **interactive lunar explorer** that uses NASA LRO/LOLA imagery to showcase authentic lunar geography.

## Why It Matters
Lunar Birthright is designed to **educate and inspire**. It introduces the principles of the OST—encouraging scientific discovery and cooperation—while making space accessible as a shared human story rather than a commodity.

## How It Works
1. Visit the website (placeholder): https://lunar-birthright.vercel.app  
2. Pick a symbolic section on the Moon (coordinates + unique ID).  
3. Generate a certificate and share your link in the **Public Registry**.  

## Legal & Ethical
The Lunar Birthright Project conforms fully to the **Outer Space Treaty**. Claims are **symbolic**, **non-transferable**, and **non-exclusive**, intended for educational and commemorative use only.

## About the Creator
**Daniel Heslip** is a New Zealand entrepreneur and community builder with a passion for education, technology, and the night sky. Lunar Birthright blends imagination and responsibility to bring space closer to everyone.

**Media Contact**  
thegreatoutdoors.fairlie@gmail.com

### ###
