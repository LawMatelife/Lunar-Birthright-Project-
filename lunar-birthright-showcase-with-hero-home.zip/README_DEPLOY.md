# Lunar Birthright — Upload (v3)

**What's inside**
- Real lunar imagery (WAC grayscale, WAC color, LOLA elevation)
- Certificate with PNG/PDF export + QR
- Public registry viewer `/registry?section=…` (with edit mode `&edit=1`)
- Toasts, spinner overlay
- OST footer + mobile ribbon
- Analytics console (Alt+A) + `/admin/events`

**How to deploy to Vercel (upload route)**
1) Go to **vercel.com/new → Upload** → select this ZIP
2) Build command: `next build`
3) (Optional) Env vars:
   - `NEXT_PUBLIC_LRO_TILE_URL=https://trek.nasa.gov/tiles/Moon/EQ/LRO_WAC_Mosaic_Global_303ppd/{z}/{x}/{y}.png`
   - `NEXT_PUBLIC_LRO_COLOR_URL=https://trek.nasa.gov/tiles/Moon/EQ/LRO_WAC_Mosaic_Global_303ppd_Color/{z}/{x}/{y}.png`
   - `NEXT_PUBLIC_LRO_ELEVATION_URL=https://trek.nasa.gov/tiles/Moon/EQ/LRO_LOLA_Shade_Global_303ppd/{z}/{x}/{y}.png`
   - `NEXT_PUBLIC_BASE_URL=https://<your-domain>`
   - `NEXT_PUBLIC_SHOW_ANALYTICS=1` (optional)

> The UI calls `/api/registry` (GET/POST). If you haven’t wired a DB yet, return a JSON object like `{ ok: true, stub: true }` so the app can still flow.

Generated: 2025-10-31T05:49:10.158816Z
