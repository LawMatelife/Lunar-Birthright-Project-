'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import dynamic from 'next/dynamic';
import { indexToCoord } from '../../lib/tiling';
import { useToast } from '../../components/ToastProvider';
import { logEvent } from '../../utils/analytics';

const MapContainer: any = dynamic(
  async () => (await import('react-leaflet')).MapContainer,
  { ssr: false }
);
const TileLayer: any = dynamic(
  async () => (await import('react-leaflet')).TileLayer,
  { ssr: false }
);
const Marker: any = dynamic(
  async () => (await import('react-leaflet')).Marker,
  { ssr: false }
);

const DEFAULT_GRAY =
  'https://trek.nasa.gov/tiles/Moon/EQ/LRO_WAC_Mosaic_Global_303ppd/{z}/{x}/{y}.png';
const TILE_URL = process.env.NEXT_PUBLIC_LRO_TILE_URL || DEFAULT_GRAY;
const ATTR = 'Imagery © NASA Moon Trek (LRO WAC/LOLA) — https://trek.nasa.gov';

type Claim = { id: number; name: string; lat?: number; lon?: number };

export default function RegistryPage() {
  const params = useSearchParams();
  const sectionStr = params.get('section');
  const editParam = params.get('edit');
  const { showToast } = useToast();

  const parsed = useMemo(() => {
    const id = sectionStr ? parseInt(sectionStr, 10) : NaN;
    if (!Number.isFinite(id) || id <= 0) return null;

    const { lat, lon } = indexToCoord(id);
    const base =
      process.env.NEXT_PUBLIC_BASE_URL?.replace(/\/+$/, '') ||
      (typeof window !== 'undefined' ? window.location.origin : '');
    const pageUrl = `${base}/registry?section=${id}`;

    return { id, lat, lon, pageUrl };
  }, [sectionStr]);

  const [loading, setLoading] = useState(false);
  const [claim, setClaim] = useState<Claim | null>(null);
  const [editing, setEditing] = useState<boolean>(editParam === '1');
  const [name, setName] = useState('');

  useEffect(() => {
    if (!parsed) return;
    const run = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/registry?section=${parsed.id}`, { cache: 'no-store' });
        const data = await res.json();
        if (!res.ok || data?.ok === false) {
          throw new Error(data?.error || 'Failed to fetch record.');
        }
        const c: Claim | null = data?.claim ?? null;
        setClaim(c);
        setName(c?.name ?? '');
      } catch (e: any) {
        showToast(e?.message || 'Could not load record.', 'error');
      } finally {
        setLoading(false);
      }
    };
    run();
  }, [parsed?.id]);

  if (!parsed) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-10">
        <h1 className="text-3xl font-bold mb-2">Public Registry</h1>
        <p className="text-sm text-gray-700">
          Provide a valid section via the URL, e.g. <code className="text-xs">/registry?section=123456</code>
        </p>
      </main>
    );
  }

  const { id, lat, lon, pageUrl } = parsed;

  async function saveName() {
    if (!name.trim()) {
      showToast('Please enter a name.', 'error');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/registry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, name: name.trim(), lat, lon })
      });
      const data = await res.json();
      const updated: Claim = { id, name: name.trim(), lat, lon };
      setClaim(updated);
      setEditing(false);

      const base =
        process.env.NEXT_PUBLIC_BASE_URL?.replace(/\/+$/, '') ||
        (typeof window !== 'undefined' ? window.location.origin : '');
      const viewUrl = `${base}/registry?section=${id}`;

      if (!res.ok || data?.ok === false) {
        throw new Error(data?.error || 'Failed to save record.');
      }

      if (data?.stub) {
        showToast('Saved (stub). Connect Supabase to persist.', 'info', [
          { label: 'View', onAction: () => { logEvent('registry_view', { id, via: 'toast' }); window.open(viewUrl, '_blank', 'noopener,noreferrer'); } },
        ]);
      } else {
        showToast('Record updated!', 'success', [
          { label: 'View', onAction: () => { logEvent('registry_view', { id, via: 'toast' }); window.open(viewUrl, '_blank', 'noopener,noreferrer'); } },
        ]);
      }
    } catch (e: any) {
      showToast(e?.message || 'Could not save.', 'error', [
        { label: 'Retry', onAction: () => saveName() },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-bold mb-2">Public Registry</h1>
      <p className="text-sm text-gray-600 mb-4">
        Symbolic lunar section details for sharing and verification.
        <br />
        <span className="text-xs text-gray-500">Not a legal land title · OST compliant</span>
      </p>

      <section className="rounded-2xl border p-4 mb-4">
        <div className="grid gap-2 sm:grid-cols-2">
          <div>
            <div className="text-sm font-semibold">Section ID</div>
            <div className="text-lg">{id}</div>
          </div>
          <div>
            <div className="text-sm font-semibold">Coordinates</div>
            <div className="text-lg">Lat {lat.toFixed(4)}°, Lon {lon.toFixed(4)}°</div>
          </div>
        </div>

        <div className="mt-3 text-sm">
          Share this link:{' '}
          <a className="underline text-blue-600 break-all" href={pageUrl} onClick={() => logEvent('registry_view', { id, via: 'link' })}>
            {pageUrl}
          </a>
        </div>

        <div className="mt-4 rounded-xl border p-3">
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold">Registrant name</div>
            {!editing ? (
              <button className="rounded-full border px-3 py-1 text-xs hover:bg-gray-50" onClick={() => setEditing(true)}>
                Edit
              </button>
            ) : (
              <button className="rounded-full border px-3 py-1 text-xs hover:bg-gray-50" onClick={() => { setEditing(false); setName(claim?.name ?? ''); }}>
                Cancel
              </button>
            )}
          </div>

          {!editing ? (
            <div className="mt-2 text-base">
              {claim?.name ? <span className="font-medium">{claim.name}</span> : <span className="text-gray-500">No name saved yet.</span>}
            </div>
          ) : (
            <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
              <input
                className="w-full rounded-xl border px-3 py-2 text-sm"
                placeholder="Enter registrant full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <button
                className="rounded-full bg-blue-600 px-4 py-2 text-white text-sm font-medium hover:bg-blue-700 disabled:opacity-60"
                disabled={loading || !name.trim()}
                onClick={saveName}
              >
                {loading ? 'Saving…' : 'Save'}
              </button>
            </div>
          )}
        </div>
      </section>

      <section className="rounded-2xl border p-4">
        <div className="mb-2 text-sm font-semibold">Location preview</div>
        <div className="overflow-hidden rounded-xl" style={{ height: 320 }}>
          <MapContainer center={[lat, lon]} zoom={4} minZoom={1} maxZoom={8} scrollWheelZoom={false} className="w-full h-full">
            <TileLayer url={TILE_URL} attribution={ATTR} />
            <Marker position={[lat, lon]} />
          </MapContainer>
        </div>
        <div className="mt-2 text-[11px] text-gray-500">
          Tiles via NASA Moon Trek. Marker is approximate for this symbolic section grid.
        </div>
      </section>
    </main>
  );
}
