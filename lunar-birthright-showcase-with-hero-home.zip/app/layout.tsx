import './globals.css';
import { ToastProvider } from '../components/ToastProvider';
import OstFooter from '../components/OstFooter';
import OstHeaderRibbon from '../components/OstHeaderRibbon';
import AnalyticsConsole from '../components/AnalyticsConsole';

const SHOW_ANALYTICS =
  process.env.NODE_ENV !== 'production' ||
  process.env.NEXT_PUBLIC_SHOW_ANALYTICS === '1';

export const metadata = {
  title: 'Lunar Birthright',
  description: 'Claim your symbolic lunar section',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <ToastProvider>
          <OstHeaderRibbon />
          {children}
          <OstFooter />
          {SHOW_ANALYTICS && <AnalyticsConsole defaultOpen={false} />}
        </ToastProvider>
      </body>
    </html>
  );
}
