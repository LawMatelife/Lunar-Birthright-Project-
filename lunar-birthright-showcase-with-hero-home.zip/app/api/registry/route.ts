import type { NextRequest } from 'next/server';

export async function GET(req: NextRequest) {
  // Example: /api/registry?section=123
  const { searchParams } = new URL(req.url);
  const section = searchParams.get('section');
  // Return a stub record (replace with real DB logic)
  return new Response(JSON.stringify({ ok: true, claim: section ? { id: Number(section), name: '' } : null }), {
    headers: { 'Content-Type': 'application/json' }
  });
}

export async function POST(req: NextRequest) {
  // Accepts: { id, name, lat, lon } — replace with DB persist
  try {
    const body = await req.json();
    // In production, save to DB here. This is a stub success response.
    return new Response(JSON.stringify({ ok: true, stub: true }), {
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (e: any) {
    return new Response(JSON.stringify({ ok: false, error: e?.message || 'Invalid JSON' }), { status: 400 });
  }
}
