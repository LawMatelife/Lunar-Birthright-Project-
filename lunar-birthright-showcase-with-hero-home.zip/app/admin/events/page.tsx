'use client';

import React from 'react';
import AnalyticsConsole from '../../../components/AnalyticsConsole';

const SHOW_ANALYTICS =
  process.env.NODE_ENV !== 'production' ||
  process.env.NEXT_PUBLIC_SHOW_ANALYTICS === '1';

export default function AdminEventsPage() {
  if (!SHOW_ANALYTICS) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-10">
        <h1 className="text-2xl font-semibold mb-2">Events Console</h1>
        <p className="text-sm text-gray-600">
          Hidden in production. Set <code className="text-xs">NEXT_PUBLIC_SHOW_ANALYTICS=1</code> to enable.
        </p>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-5xl px-4 py-6">
        <h1 className="text-2xl font-semibold mb-2">Lunar Analytics — Live Stream</h1>
        <p className="text-sm text-gray-600 mb-4">
          This page listens to <code className="text-xs">lb_analytics</code> events emitted across the app.
          Use Alt+A anywhere to toggle the floating console. Here, the console is docked full-screen.
        </p>
        <div className="rounded-2xl border bg-white shadow-sm">
          <AnalyticsConsole defaultOpen={true} />
        </div>
      </div>
    </main>
  );
}
