'use client';
import React, { useMemo, useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import QRCode from 'qrcode';
import SpinnerOverlay from '../components/SpinnerOverlay';
import { useToast } from '../components/ToastProvider';
import { logEvent } from '../utils/analytics';

const Lro = dynamic(() => import('../components/Lro'), { ssr: false });

type Picked = { id: number; lat: number; lon: number } | null;

export default function Page() {
  const [picked, setPicked] = useState<Picked>(null);
  const [name, setName] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);

  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);

  const { showToast } = useToast();

  const registryUrl = useMemo(() => {
    const base =
      process.env.NEXT_PUBLIC_BASE_URL?.replace(/\/+$/, '') ||
      (typeof window !== 'undefined' ? window.location.origin : 'https://example.com');
    const id = picked?.id ?? '';
    return `${base}/registry?section=${id}`;
  }, [picked?.id]);

  useEffect(() => {
    if (!picked) {
      setQrDataUrl(null);
      return;
    }
    QRCode.toDataURL(registryUrl, { width: 200, margin: 1 })
      .then(setQrDataUrl)
      .catch(() => setQrDataUrl(null));
  }, [registryUrl, picked]);

  const copyCoords = async () => {
    if (!picked) return;
    const text = `Section #${picked.id} — Lat ${picked.lat.toFixed(4)}°, Lon ${picked.lon.toFixed(4)}°`;
    try {
      await navigator.clipboard.writeText(text);
      logEvent('copy_coords', { id: picked.id });
      showToast('Copied coordinates to clipboard', 'success');
    } catch {
      prompt('Copy coordinates:', text);
      logEvent('copy_coords', { id: picked.id, fallback: true });
      showToast('Copied (manual)', 'info');
    }
  };

  async function saveClaim() {
    if (!picked || !name) return;
    setSaving(true);
    try {
      const res = await fetch('/api/registry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: picked.id,
          name: name.trim(),
          lat: picked.lat,
          lon: picked.lon,
        }),
      });
      const data = await res.json();
      const base =
        process.env.NEXT_PUBLIC_BASE_URL?.replace(/\/+$/, '') ||
        (typeof window !== 'undefined' ? window.location.origin : '');
      const viewUrl = `${base}/registry?section=${picked.id}`;
      const editUrl = `${viewUrl}&edit=1`;

      if (!res.ok || data?.ok === false) {
        throw new Error(data?.error || 'Failed to save');
      }

      if (data?.stub) {
        logEvent('claim_save_stub', { id: picked.id });
        showToast('Saved (stub) — connect Supabase to persist.', 'info', [
          { label: 'View', onAction: () => { logEvent('registry_view', { id: picked.id, via: 'toast' }); window.open(viewUrl, '_blank', 'noopener,noreferrer'); } },
          { label: 'Edit', onAction: () => { logEvent('registry_edit', { id: picked.id, via: 'toast' }); window.open(editUrl, '_blank', 'noopener,noreferrer'); } },
        ]);
      } else {
        logEvent('claim_save_ok', { id: picked.id });
        showToast('Saved to registry!', 'success', [
          { label: 'View', onAction: () => { logEvent('registry_view', { id: picked.id, via: 'toast' }); window.open(viewUrl, '_blank', 'noopener,noreferrer'); } },
          { label: 'Edit', onAction: () => { logEvent('registry_edit', { id: picked.id, via: 'toast' }); window.open(editUrl, '_blank', 'noopener,noreferrer'); } },
        ]);
      }
    } catch (err: any) {
      logEvent('claim_save_err', { id: picked?.id, message: err?.message });
      showToast(err?.message || 'Could not save.', 'error', [
        { label: 'Retry', onAction: () => saveClaim() },
      ]);
    } finally {
      setSaving(false);
    }
  }

  const savePNG = async () => {
    try {
      setExporting(true);
      const el = document.getElementById('cert');
      if (!el) { showToast('Nothing to export yet — pick a spot and enter your name.', 'error'); return; }
      const c = await html2canvas(el, { scale: 2 });
      const a = document.createElement('a');
      a.href = c.toDataURL('image/png');
      a.download = 'lunar-certificate.png';
      a.click();
      logEvent('download_png', { id: picked?.id });
      showToast('PNG downloaded', 'success');
    } catch (e: any) {
      showToast(e?.message || 'Could not create PNG.', 'error');
    } finally {
      setExporting(false);
    }
  };

  const savePDF = async () => {
    try {
      setExporting(true);
      const el = document.getElementById('cert');
      if (!el) { showToast('Nothing to export yet — pick a spot and enter your name.', 'error'); return; }
      const c = await html2canvas(el, { scale: 2 });
      const pdf = new jsPDF('p', 'pt', 'a4');
      const img = c.toDataURL('image/png');
      const w = pdf.internal.pageSize.getWidth();
      const h = pdf.internal.pageSize.getHeight();
      const ratio = Math.min(w / c.width, h / c.height);
      const iw = c.width * ratio;
      const ih = c.height * ratio;
      pdf.addImage(img, 'PNG', (w - iw) / 2, 40, iw, ih);
      pdf.save('lunar-certificate.pdf');
      logEvent('download_pdf', { id: picked?.id });
      showToast('PDF downloaded', 'success');
    } catch (e: any) {
      showToast(e?.message || 'Could not create PDF.', 'error');
    } finally {
      setExporting(false);
    }
  };

  return (
    <main className="px-0 pb-10">
      {/* Hero */}
      <section className="relative w-full overflow-hidden bg-black/90">
        <div className="mx-auto max-w-6xl px-4 py-8 sm:py-10">
          <div className="relative aspect-[5/2] w-full overflow-hidden rounded-2xl ring-1 ring-white/10">
            <video
              className="h-full w-full object-cover"
              src="/hero-video/hero.mp4"
              autoPlay
              loop
              muted
              playsInline
              onPlay={() => logEvent('hero_video_play')}
              onError={() => logEvent('hero_video_error')}
            />
            {/* Fallback banner overlay */}
            <div className="pointer-events-none absolute inset-0 bg-[url('/banner.png')] bg-cover bg-center opacity-0 [video[error]&]:opacity-100 [video:not(:defined)]:opacity-100" />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/60 to-black/10" />
            <div className="absolute inset-x-0 bottom-0 p-4 sm:p-6">
              <h1 className="text-3xl sm:text-4xl font-bold text-white drop-shadow">
                Lunar Birthright Project
              </h1>
              <p className="mt-1 max-w-2xl text-sm sm:text-base text-white/90">
                A symbolic global birthright giving every human a piece of the Moon — with real NASA lunar imagery.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="px-4 pt-6">
        <p className="text-sm text-gray-600 mb-4 text-center">
          Pick a spot on real lunar imagery, then generate a symbolic certificate.
        </p>

        <Lro onPick={(info) => setPicked(info)} />

        <section className="mx-auto mt-4 max-w-4xl rounded-2xl border p-4">
          <div className="grid items-center gap-3 sm:grid-cols-4">
            <div className="text-sm">
              <div className="font-semibold">Picked location</div>
              {picked ? (
                <div className="text-gray-700">
                  Section #{picked.id}<br />
                  Lat {picked.lat.toFixed(4)}°, Lon {picked.lon.toFixed(4)}°
                </div>
              ) : (
                <div className="text-gray-500">Tap the map to choose.</div>
              )}
            </div>

            <input
              className="rounded-xl border px-3 py-2 text-sm sm:col-span-2"
              placeholder="Your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <div className="flex flex-wrap gap-2">
              <button className="btn btn-ghost" disabled={!picked || !name || saving} onClick={saveClaim} title="Save this claim to the public registry">
                {saving ? 'Saving…' : 'Save to registry'}
              </button>
              <button className="btn btn-primary" disabled={!picked || !name || saving || exporting} onClick={savePNG}>
                Download PNG
              </button>
              <button className="btn btn-ghost" disabled={!picked || !name || saving || exporting} onClick={savePDF}>
                Download PDF
              </button>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
            <button className="btn btn-ghost" disabled={!picked} onClick={copyCoords} title="Copy section ID and coordinates">
              Copy coordinates
            </button>

            {picked && (
              <>
                <a
                  className="underline text-blue-600"
                  href={registryUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="Open public registry link"
                  onClick={() => logEvent('registry_view', { id: picked?.id, via: 'link' })}
                >
                  Open registry link
                </a>
                <span className="text-gray-400">·</span>
                <span className="text-gray-600 break-all">{registryUrl}</span>
              </>
            )}
          </div>
        </section>

        {picked && name && (
          <section id="cert" className="mx-auto mt-6 max-w-3xl rounded-2xl border p-6">
            <div className="mb-1 text-center text-xs text-gray-600">Symbolic Certificate</div>
            <h2 className="mb-4 text-center text-2xl font-semibold">Lunar Birthright Project™</h2>
            <div className="mb-2 text-center text-sm">This certifies that</div>
            <div className="mb-2 text-center text-xl font-semibold">{name}</div>
            <div className="text-center text-sm">
              is symbolic steward of Section #{picked.id}<br />
              Lat {picked.lat.toFixed(4)}°, Lon {picked.lon.toFixed(4)}°
            </div>

            <div className="mt-4 flex items-center justify-center">
              {qrDataUrl ? (
                <a href={registryUrl} target="_blank" rel="noopener noreferrer" title="Open registry" onClick={() => logEvent('registry_view', { id: picked?.id, via: 'qr' })}>
                  <img src={qrDataUrl} alt="Registry QR" className="h-40 w-40" />
                </a>
              ) : (
                <div className="text-xs text-gray-500">Preparing QR…</div>
              )}
            </div>

            <div className="mt-4 flex justify-center gap-2">
              <a
                href={registryUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-full bg-blue-600 px-6 py-2 text-white text-sm font-medium hover:bg-blue-700 transition"
                onClick={() => logEvent('registry_view', { id: picked?.id, via: 'button' })}
              >
                View record ↗
              </a>
              <a
                href={`${registryUrl}&edit=1`}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-full border px-6 py-2 text-sm font-medium hover:bg-gray-50 transition"
                onClick={() => logEvent('registry_edit', { id: picked?.id, via: 'button' })}
              >
                Edit record ✎
              </a>
            </div>

            <div className="mt-4 text-center text-xs text-gray-600 flex flex-col items-center gap-1">
              <div>Not a legal land title · OST compliant</div>
              <div className="group relative inline-block">
                <button
                  className="text-blue-600 hover:text-blue-700 underline underline-offset-2 text-xs cursor-pointer"
                  title="Click to learn about OST compliance"
                  onClick={() => window.open('https://www.unoosa.org/oosa/en/ourwork/spacelaw/treaties/introouterspacetreaty.html', '_blank', 'noopener,noreferrer')}
                >
                  Learn about the 1967 Outer Space Treaty
                </button>
                <span className="absolute hidden group-hover:block -top-16 left-1/2 -translate-x-1/2 w-72 rounded-md bg-gray-900 text-white text-[11px] p-2 text-center shadow-xl">
                  The 1967 Outer Space Treaty (OST) prohibits ownership of celestial bodies.
                  All claims here are symbolic and educational, not legal property rights.
                </span>
              </div>
            </div>
          </section>
        )}

        <SpinnerOverlay show={saving} label="Saving to registry…" />
      </section>
    </main>
  );
}
