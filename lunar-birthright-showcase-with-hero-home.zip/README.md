![Lunar Birthright Banner](public/banner.png)

# 🌕 Lunar Birthright Project
### “A symbolic global birthright project giving every human a unique section of the Moon — powered by NASA imagery and the Outer Space Treaty.”

**Created by Daniel Heslip — Fairlie, New Zealand**

---

## 🛰️ Vision
**Lunar Birthright** connects every person with a *symbolic* piece of the Moon — not as property, but as a shared story of exploration and unity.

At birth, each person receives a **symbolic lunar section** (quarter-acre equivalent) displayed on an authentic NASA Moon map. Each section is a celebration of imagination, community, and the dream of going farther together.

---

## 🌍 Mission
- Build a **global digital registry** of symbolic lunar sections linked to births, families, and communities.  
- Render **real lunar terrain** using NASA LRO/LOLA imagery.  
- Promote awareness of the **1967 Outer Space Treaty (OST)** — enabling peaceful use but prohibiting ownership.  
- Inspire future generations to explore, protect, and understand our place in the cosmos.

---

## ✨ Platform Highlights
- **Real Lunar Imagery** — NASA Moon Trek (WAC grayscale, WAC color, LOLA elevation)
- **Interactive Section Picker** — pick a unique grid location
- **Certificate Exports** — downloadable PDF/PNG with QR verification link
- **Public Registry Page** — `/registry?section=…` (+ `&edit=1` mode)
- **OST Compliance** — clear disclaimers on every page
- **Analytics** — press **Alt + A** for live events console; `/admin/events`

> Live site: *(placeholder)* https://lunar-birthright.vercel.app

---

## ⚖️ Outer Space Treaty (1967)
> “Outer space, including the Moon and other celestial bodies, is not subject to national appropriation by claim of sovereignty, by means of use or occupation, or by any other means.”

Lunar Birthright operates within this **symbolic & educational** framework. All claims are **non-legal and non-exclusive**.

Learn more → https://www.unoosa.org/oosa/en/ourwork/spacelaw/treaties/introouterspacetreaty.html

---

## 🧱 Tech Stack
- Next.js 14 (App Router), React 18, Tailwind CSS  
- Leaflet / React-Leaflet for maps  
- html2canvas + jsPDF for certificate exports  
- Framer Motion for toasts/animations  
- Vercel + GitHub Actions for CI/CD

---

## 🚀 Quick Start (Local)
```bash
npm install
npm run dev
# open http://localhost:3000
```

**Environment variables (optional):**
```
NEXT_PUBLIC_LRO_TILE_URL=https://trek.nasa.gov/tiles/Moon/EQ/LRO_WAC_Mosaic_Global_303ppd/{z}/{x}/{y}.png
NEXT_PUBLIC_BASE_URL=https://your-domain
NEXT_PUBLIC_SHOW_ANALYTICS=1
```

---

## 🪙 Status
This repository is a **private showcase / business proposal**.

Partnerships, sponsorships, and collaboration inquiries:  
**thegreatoutdoors.fairlie@gmail.com**

© 2025 Daniel Heslip — Lunar Birthright Project • All rights reserved.
