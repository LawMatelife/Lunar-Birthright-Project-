'use client';
import React from 'react';

export default function SpinnerOverlay({ show, label = 'Saving…' }: { show: boolean; label?: string }) {
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="flex flex-col items-center gap-3 rounded-2xl bg-white px-6 py-5 shadow-xl">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-gray-300 border-t-gray-900" />
        <div className="text-sm font-medium text-gray-900">{label}</div>
      </div>
    </div>
  );
}
