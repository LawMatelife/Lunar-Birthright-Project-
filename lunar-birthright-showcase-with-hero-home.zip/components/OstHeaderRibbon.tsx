'use client';
import React, { useEffect, useState } from 'react';
import { logEvent } from '../utils/analytics';

const DISMISS_KEY = 'ostHeaderRibbonDismissed_v1';

export default function OstHeaderRibbon() {
  const [open, setOpen] = useState(true);
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    try {
      const v = localStorage.getItem(DISMISS_KEY);
      if (v === '1') setOpen(false);
    } catch {}
  }, []);

  useEffect(() => {
    if (!open) return;
    logEvent('ribbon_shown');
    const t = setTimeout(() => {
      setCollapsed(true);
      logEvent('ribbon_collapsed');
    }, 5000);
    return () => clearTimeout(t);
  }, [open]);

  const dismiss = () => {
    try { localStorage.setItem(DISMISS_KEY, '1'); } catch {}
    setOpen(false);
    logEvent('ribbon_dismissed');
  };

  if (!open) return null;

  return (
    <div className="sticky top-0 z-40 block sm:hidden">
      {!collapsed ? (
        <div className="mx-2 mt-2 rounded-xl border bg-white/95 px-3 py-2 text-[11px] shadow-md backdrop-blur">
          <div className="flex items-start gap-2">
            <span className="mt-[2px] inline-block h-2 w-2 rounded-full bg-blue-600" />
            <div className="flex-1 leading-snug text-gray-800">
              <span className="font-semibold">OST notice:</span> All Lunar Birthright sections are
              <span className="font-semibold"> symbolic</span> (non-legal), compliant with the 1967 Outer Space Treaty.
              <a
                href="https://www.unoosa.org/oosa/en/ourwork/spacelaw/treaties/introouterspacetreaty.html"
                target="_blank"
                rel="noopener noreferrer"
                className="ml-1 text-blue-600 underline underline-offset-2"
                onClick={() => logEvent('ribbon_learn_more')}
              >
                Learn more
              </a>
            </div>

            <button
              onClick={() => { setCollapsed(true); logEvent('ribbon_collapsed'); }}
              className="ml-2 rounded-full border px-2 py-0.5 text-[10px] leading-4 text-gray-700 hover:bg-gray-50"
              aria-label="Collapse"
              title="Collapse"
            >
              Hide
            </button>
            <button
              onClick={dismiss}
              className="ml-1 rounded-full border px-2 py-0.5 text-[10px] leading-4 text-gray-700 hover:bg-gray-50"
              aria-label="Dismiss"
              title="Dismiss forever"
            >
              Dismiss
            </button>
          </div>
        </div>
      ) : (
        <div className="mx-auto mt-2 flex w-full justify-center">
          <button
            onClick={() => { setCollapsed(false); logEvent('ribbon_expanded'); }}
            className="flex items-center gap-2 rounded-full border bg-white/95 px-3 py-1 text-[10px] text-gray-800 shadow-sm backdrop-blur"
            aria-label="Show OST notice"
            title="Show OST notice"
          >
            <span className="inline-block h-2 w-2 rounded-full bg-blue-600" />
            OST notice
          </button>
          <button
            onClick={dismiss}
            className="ml-2 rounded-full border bg-white/95 px-2 py-1 text-[10px] text-gray-700 shadow-sm backdrop-blur"
            aria-label="Dismiss"
            title="Dismiss forever"
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}
