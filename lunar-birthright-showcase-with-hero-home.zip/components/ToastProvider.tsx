'use client';
import React, { createContext, useContext, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

type ToastAction = { label: string; onAction: () => void };
type ToastType = 'success' | 'error' | 'info';

type Toast = {
  id: number;
  text: string;
  type: ToastType;
  actions?: ToastAction[];
};

type ToastContextType = {
  showToast: (text: string, type?: ToastType, actions?: ToastAction[]) => void;
};

const ToastContext = createContext<ToastContextType>({ showToast: () => {} });
let idCounter = 0;

export function useToast() {
  return useContext(ToastContext);
}

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((text: string, type: ToastType = 'info', actions?: ToastAction[]) => {
    const id = ++idCounter;
    setToasts((prev) => [...prev, { id, text, type, actions }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  }, []);

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className={`flex items-center gap-3 rounded-xl px-4 py-2 text-sm shadow-md ${
                t.type === 'success'
                  ? 'bg-green-600 text-white'
                  : t.type === 'error'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-800 text-white'
              }`}
            >
              <span className="leading-tight">{t.text}</span>
              {t.actions && t.actions.length > 0 && (
                <div className="ml-2 flex flex-wrap items-center gap-2">
                  {t.actions.map((a, idx) => (
                    <button
                      key={idx}
                      onClick={a.onAction}
                      className="rounded-full bg-white/15 px-2.5 py-1 text-xs hover:bg-white/25"
                    >
                      {a.label}
                    </button>
                  ))}
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
};
