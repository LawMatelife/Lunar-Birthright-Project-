'use client';

import dynamic from 'next/dynamic';
import React, { useMemo, useState } from 'react';

const MapContainer: any = dynamic(
  async () => (await import('react-leaflet')).MapContainer,
  { ssr: false }
);
const TileLayer: any = dynamic(
  async () => (await import('react-leaflet')).TileLayer,
  { ssr: false }
);

type Props = { onPick: (info: { id: number; lat: number; lon: number }) => void };

const DEFAULT_GRAY =
  'https://trek.nasa.gov/tiles/Moon/EQ/LRO_WAC_Mosaic_Global_303ppd/{z}/{x}/{y}.png';
const DEFAULT_COLOR =
  'https://trek.nasa.gov/tiles/Moon/EQ/LRO_WAC_Mosaic_Global_303ppd_Color/{z}/{x}/{y}.png';
const DEFAULT_ELEV =
  'https://trek.nasa.gov/tiles/Moon/EQ/LRO_LOLA_Shade_Global_303ppd/{z}/{x}/{y}.png';

const URL_GRAY = process.env.NEXT_PUBLIC_LRO_TILE_URL || DEFAULT_GRAY;
const URL_COLOR = process.env.NEXT_PUBLIC_LRO_COLOR_URL || DEFAULT_COLOR;
const URL_ELEV  = process.env.NEXT_PUBLIC_LRO_ELEVATION_URL || DEFAULT_ELEV;

const ATTR = 'Imagery © NASA Moon Trek (LRO WAC/LOLA) — https://trek.nasa.gov';

export default function Lro({ onPick }: Props) {
  const [mode, setMode] = useState<'gray' | 'color' | 'elev'>('gray');

  const activeUrl = useMemo(() => {
    if (mode === 'color') return URL_COLOR;
    if (mode === 'elev')  return URL_ELEV;
    return URL_GRAY;
  }, [mode]);

  const handleClick = (e: any) => {
    const lat = e.latlng.lat as number;
    const lon = e.latlng.lng as number;
    const id =
      Math.floor(((90 - lat) / 180) * 1800) * 3600 +
      Math.floor(((lon + 180) / 360) * 3600) +
      1;
    onPick({ id, lat, lon });
  };

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-3 flex items-center gap-3">
        <label className="text-sm font-medium">Imagery:</label>
        <select
          className="rounded-xl border px-3 py-2 text-sm"
          value={mode}
          onChange={(e) => setMode(e.target.value as any)}
        >
          <option value="gray">Grayscale (WAC)</option>
          <option value="color">Color (WAC)</option>
          <option value="elev">Elevation (LOLA hillshade)</option>
        </select>
      </div>

      <MapContainer
        center={[0, 0]}
        zoom={2}
        minZoom={1}
        maxZoom={8}
        scrollWheelZoom
        className="leaflet-container"
        whenCreated={(m: any) => m.on('click', handleClick)}
      >
        <TileLayer url={activeUrl} attribution={ATTR} />
      </MapContainer>

      <div className="mt-3 grid gap-2 rounded-2xl border p-3 text-xs text-gray-700">
        <div className="font-semibold">Legend</div>
        <div className="grid gap-1 sm:grid-cols-3">
          <div><div className="font-medium">Grayscale (WAC)</div><div>Global mosaic from Lunar Reconnaissance Orbiter (WAC).</div></div>
          <div><div className="font-medium">Color (WAC)</div><div>Enhanced color composite (varies by region/source).</div></div>
          <div><div className="font-medium">Elevation (LOLA)</div><div>Hillshade from LOLA topography.</div></div>
        </div>
        <div className="text-[11px] text-gray-500">Tiles via NASA Moon Trek. Click the map to pick a symbolic section.</div>
      </div>
    </div>
  );
}
