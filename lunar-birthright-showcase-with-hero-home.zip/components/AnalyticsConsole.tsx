'use client';
import React, { useEffect, useRef, useState } from 'react';

type Row = { t: string; name: string; params?: Record<string, any> };

export default function AnalyticsConsole({
  defaultOpen = false,
  maxRows = 200,
}: {
  defaultOpen?: boolean;
  maxRows?: number;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const [paused, setPaused] = useState(false);
  const [rows, setRows] = useState<Row[]>([]);
  const listRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const onEvt = (e: Event) => {
      if (paused) return;
      const ce = e as CustomEvent<{ name: string; params?: Record<string, any> }>;
      const t = new Date().toISOString().split('T')[1]?.replace('Z', '');
      setRows((prev) => {
        const next = [...prev, { t, name: ce.detail.name, params: ce.detail.params }];
        if (next.length > maxRows) next.shift();
        return next;
      });
    };
    document.addEventListener('lb_analytics' as any, onEvt);
    return () => document.removeEventListener('lb_analytics' as any, onEvt);
  }, [paused, maxRows]);

  useEffect(() => {
    if (!listRef.current || paused) return;
    listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [rows, paused]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'a' || e.key === 'A')) setOpen((v) => !v);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-4 right-4 z-[60] rounded-full border bg-white/90 px-3 py-1.5 text-xs shadow hover:bg-white"
        title="Open analytics (Alt+A)"
      >
        Analytics
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-[60] w-[min(92vw,380px)] overflow-hidden rounded-2xl border bg-white/95 shadow-xl backdrop-blur">
      <div className="flex items-center justify-between border-b px-3 py-2">
        <div className="text-xs font-semibold">Lunar Analytics (Alt+A)</div>
        <div className="flex items-center gap-2">
          <button onClick={() => setPaused((p) => !p)} className="rounded-full border px-2 py-0.5 text-[11px] hover:bg-gray-50" title={paused ? 'Resume' : 'Pause'}>
            {paused ? 'Resume' : 'Pause'}
          </button>
          <button onClick={() => setRows([])} className="rounded-full border px-2 py-0.5 text-[11px] hover:bg-gray-50" title="Clear">
            Clear
          </button>
          <button onClick={() => setOpen(false)} className="rounded-full border px-2 py-0.5 text-[11px] hover:bg-gray-50" title="Close">
            ×
          </button>
        </div>
      </div>
      <div ref={listRef} className="max-h-[50vh] overflow-auto px-3 py-2 text-[11px] leading-5">
        {rows.length === 0 ? (
          <div className="select-text text-gray-500">No events yet…</div>
        ) : (
          rows.map((r, i) => (
            <div key={i} className="select-text">
              <span className="text-gray-400">{r.t}</span>{' '}
              <span className="font-medium">{r.name}</span>
              {r.params ? (
                <pre className="mt-0.5 ml-4 inline-block whitespace-pre-wrap break-all text-[10px] text-gray-700">
                  {JSON.stringify(r.params, null, 0)}
                </pre>
              ) : null}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
