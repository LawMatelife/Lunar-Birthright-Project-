'use client';
import React, { useEffect, useState } from 'react';
import { logEvent } from '../utils/analytics';

const KEY = 'ostFooterDismissed_v1';

export default function OstFooter() {
  const [open, setOpen] = useState(true);

  useEffect(() => {
    try {
      const v = localStorage.getItem(KEY);
      if (v === '1') setOpen(false);
      else logEvent('footer_shown');
    } catch {}
  }, []);

  const dismiss = () => {
    try { localStorage.setItem(KEY, '1'); } catch {}
    setOpen(false);
    logEvent('footer_dismissed');
  };

  if (!open) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-40">
      <div className="mx-auto max-w-5xl">
        <div className="m-3 rounded-2xl border bg-white/95 p-4 shadow-lg backdrop-blur sm:flex sm:items-center sm:justify-between">
          <p className="text-xs leading-relaxed text-gray-700">
            <span className="font-semibold">Outer Space Treaty (1967):</span>{' '}
            Ownership of celestial bodies is prohibited. All “Lunar Birthright” sections are
            <span className="font-semibold"> symbolic</span> and <span className="font-semibold">non-legal</span>,
            intended for education and entertainment, not property rights.
            {' '}
            <a
              className="text-blue-600 underline underline-offset-2 hover:text-blue-700"
              href="https://www.unoosa.org/oosa/en/ourwork/spacelaw/treaties/introouterspacetreaty.html"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => logEvent('footer_learn_more')}
            >
              Learn more
            </a>.
          </p>

          <div className="mt-3 flex gap-2 sm:mt-0 sm:ml-4">
            <button
              onClick={dismiss}
              className="rounded-full bg-gray-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-black"
            >
              Got it
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
